let usu1 = prompt(&amp;quot;Digite o usuário:&amp;quot;);
let senh1 = prompt(&amp;quot;Digite a senha:&amp;quot;);

switch (usu1 + &amp;quot;-&amp;quot; + senh1) {
case &amp;quot;pietra-1234&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;isabelly-4321&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;caua-5654&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;gabi-6767&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;moises-7676&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;
case &amp;quot;lucas-6666&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;breno-6709&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);

break;

case &amp;quot;bruna-0001&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;vitor-6768&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

case &amp;quot;arthur-7675&amp;quot;:
console.log(&amp;quot;Bem vindo ao sistema&amp;quot;);
break;

default:
console.log(&amp;quot;Usuário ou senha incorretos&amp;quot;);