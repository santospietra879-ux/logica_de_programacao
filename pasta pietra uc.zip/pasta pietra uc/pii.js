let idioma = 1;

switch (idioma) {
case 1:
console.log(&quot;Olá&quot;); // Português
break;

case 2:
console.log(&quot;Hello&quot;); // Inglês
break;

case 3:
console.log(&quot;Hola&quot;); // Espanhol
break;

default:
console.log(&quot;Idioma inválido&quot;);
}

EXERCÍCIO 2 — Dias da semana

let dia = 2;

switch (dia) {
case 1:
console.log(&quot;Domingo&quot;);
break;

case 2:
console.log(&quot;Segunda-feira&quot;);
break;

case 3:
console.log(&quot;Terça-feira&quot;);
break;

case 4:
console.log(&quot;Quarta-feira&quot;);
break;

case 5:
console.log(&quot;Quinta-feira&quot;);
break;

case 6:
console.log(&quot;Sexta-feira&quot;);
break;

case 7:
console.log(&quot;Sábado&quot;);
break;

default:
console.log(&quot;Dia inválido&quot;);
}
EXERCÍCIO 3 — Transporte

let transporte = 1;

switch (transporte) {
case 1:
console.log(&quot;Carro&quot;);
break;

case 2:
console.log(&quot;Bicicleta&quot;);
break;

case 3:
console.log(&quot;Ônibus&quot;);
break;

default:
console.log(&quot;Opção inválida&quot;);
}

EXERCÍCIO 4 — Urgência
let nivel = 3;

switch (nivel) {
case 1:
console.log(&quot;Baixa&quot;);
break;

case 2:

console.log(&quot;Média&quot;);
break;

case 3:
console.log(&quot;Alta&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}
EXERCÍCIO 6 — Tipos de veículos
let tipo = &quot;SUV&quot;;

switch (tipo) {
case &quot;compacto&quot;:
console.log(&quot;Veículo compacto&quot;);
break;

case &quot;SUV&quot;:
console.log(&quot;Veículo SUV&quot;);
break;

case &quot;caminhão&quot;:
console.log(&quot;Caminhão&quot;);
break;

default:
console.log(&quot;Tipo inválido&quot;);
}

EXERCÍCIO 7 — Estacionamento
let horas = 2;

switch (horas) {
case 1:
console.log(&quot;R$ 5&quot;);
break;

case 2:
console.log(&quot;R$ 10&quot;);
break;

case 3:
console.log(&quot;R$ 15&quot;);
break;

default:
console.log(&quot;Valor a combinar&quot;);
}

EXERCÍCIO 8 — Dificuldade
let nivel = 1;

switch (nivel) {
case 1:
console.log(&quot;Fácil&quot;);
break;

case 2:
console.log(&quot;Médio&quot;);
break;

case 3:
console.log(&quot;Difícil&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}
EXERCÍCIO 9 — Academia

let servico = 2;

switch (servico) {
case 1:
console.log(&quot;Yoga&quot;);
break;

case 2:
console.log(&quot;Musculação&quot;);
break;

case 3:
console.log(&quot;Personal Trainer&quot;);
break;

default:

console.log(&quot;Inválido&quot;);
}

EXERCÍCIO 10 — Ingressos

let ingresso = 1;

switch (ingresso) {
case 1:
console.log(&quot;Estudante&quot;);
break;

case 2:
console.log(&quot;Meia entrada&quot;);
break;

case 3:
console.log(&quot;Inteira&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}

EXERCÍCIO 10 (2) — Faixa etária

let idade = 18;

switch (true) {

case (idade &lt; 12):
console.log(&quot;Fácil&quot;);
break;

case (idade &gt;= 12 &amp;&amp; idade &lt; 18):
console.log(&quot;Médio&quot;);
break;

case (idade &gt;= 18):
console.log(&quot;Difícil&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}

EXERCÍCIO 11 — Instrumentos
let genero = &quot;rock&quot;;

switch (genero) {
case &quot;rock&quot;:
console.log(&quot;Guitarra&quot;);
break;

case &quot;samba&quot;:
console.log(&quot;Pandeiro&quot;);
break;

case &quot;classico&quot;:

console.log(&quot;Violino&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}

EXERCÍCIO 12 — Cursos
let area = &quot;front-end&quot;;

switch (area) {
case &quot;front-end&quot;:
console.log(&quot;HTML, CSS, JavaScript&quot;);
break;

case &quot;back-end&quot;:
console.log(&quot;Node.js, banco de dados&quot;);
break;

case &quot;mobile&quot;:
console.log(&quot;Apps para celular&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}
EXERCÍCIO 13 — Esportes
let idade = 15;

switch (true) {
case (idade &lt; 12):
console.log(&quot;Iniciante&quot;);
break;

case (idade &gt;= 12 &amp;&amp; idade &lt; 18):
console.log(&quot;Intermediário&quot;);
break;

case (idade &gt;= 18):
console.log(&quot;Avançado&quot;);
break;

default:
console.log(&quot;Inválido&quot;);
}
EXERCÍCIO 14 — Matemática
let nivel = &quot;basico&quot;;

switch (nivel) {
case &quot;basico&quot;:
console.log(&quot;Fácil&quot;);
break;

case &quot;intermediario&quot;:
console.log(&quot;Médio&quot;);
break;

case &quot;avancado&quot;:

console.log(&quot;Difícil&quot;);
break;

default:
console.log(&quot;Inválido&quot;);