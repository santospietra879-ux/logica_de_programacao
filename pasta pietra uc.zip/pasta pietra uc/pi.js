console.log(&quot;Seja bem-vindo ao Quiz de Programação ��\n&quot;);

// Pergunta 1
console.log(&quot;1) O que o if faz?&quot;);
console.log(&quot;a) Repete código&quot;);
console.log(&quot;b) Faz uma comparação&quot;);
let resposta1 = &quot;a&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta1);

if (resposta1 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 2
console.log(&quot;2) O que o else faz?&quot;);
console.log(&quot;a) Executa se for falso&quot;);
console.log(&quot;b) Executa se for verdadeiro&quot;);
let resposta2 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta2);

if (resposta2 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 3

console.log(&quot;3) Qual operador significa igual?&quot;);
console.log(&quot;a) =&quot;);
console.log(&quot;b) ==&quot;);
let resposta3 = &quot;a&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta3);

if (resposta3 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 4
console.log(&quot;4) Qual operador significa diferente?&quot;);
console.log(&quot;a) !=&quot;);
console.log(&quot;b) ==&quot;);
let resposta4 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta4);

if (resposta4 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 5
console.log(&quot;5) 20 &gt;= 18 é:&quot;);
console.log(&quot;a) Verdadeiro&quot;);
console.log(&quot;b) Falso&quot;);

let resposta5 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta5);

if (resposta5 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 6
console.log(&quot;6) 10 == 5 é:&quot;);
console.log(&quot;a) Verdadeiro&quot;);
console.log(&quot;b) Falso&quot;);
let resposta6 = &quot;b&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta6);

if (resposta6 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 7
console.log(&quot;7) if(5 &gt; 2) é:&quot;);
console.log(&quot;a) Verdadeiro&quot;);
console.log(&quot;b) Falso&quot;);
let resposta7 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta7);

if (resposta7 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 8
console.log(&quot;8) else executa quando:&quot;);
console.log(&quot;a) Verdadeiro&quot;);
console.log(&quot;b) Falso&quot;);
let resposta8 = &quot;b&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta8);

if (resposta8 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 9
console.log(&quot;9) 0 &gt; 1 é:&quot;);
console.log(&quot;a) Verdadeiro&quot;);
console.log(&quot;b) Falso&quot;);
let resposta9 = &quot;a&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta9);

if (resposta9 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {

console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 10
console.log(&quot;10) if(3 == 3) é:&quot;);
console.log(&quot;a) Verdadeiro&quot;);
console.log(&quot;b) Falso&quot;);
let resposta10 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta10);

if (resposta10 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

console.log(&quot;Fim do quiz &quot;);

console.log(&quot;Seja bem-vindo ao Quiz de Conhecimentos Gerai\n&quot;);

// Pergunta 1
console.log(&quot;1) Qual é a capital do Brasil?&quot;);
console.log(&quot;a) Rio de Janeiro&quot;);
console.log(&quot;b) Brasília&quot;);
let resposta1 = &quot;b&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta1);

if (resposta1 == &quot;b&quot;) {

console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 2
console.log(&quot;2) Quantos dias tem um ano?&quot;);
console.log(&quot;a) 365&quot;);
console.log(&quot;b) 300&quot;);
let resposta2 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta2);

if (resposta2 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 3
console.log(&quot;3) Qual planeta é conhecido como planeta vermelho?&quot;);
console.log(&quot;a) Marte&quot;);
console.log(&quot;b) Vênus&quot;);
let resposta3 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta3);

if (resposta3 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);

}

// Pergunta 4
console.log(&quot;4) Qual é o maior oceano do mundo?&quot;);
console.log(&quot;a) Atlântico&quot;);
console.log(&quot;b) Pacífico&quot;);
let resposta4 = &quot;a&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta4);

if (resposta4 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 5
console.log(&quot;5) Quem descobriu o Brasil?&quot;);
console.log(&quot;a) Pedro Álvares Cabral&quot;);
console.log(&quot;b) Cristóvão Colombo&quot;);
let resposta5 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta5);

if (resposta5 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 6

console.log(&quot;6) Qual é o resultado de 2 + 2?&quot;);
console.log(&quot;a) 4&quot;);
console.log(&quot;b) 5&quot;);
let resposta6 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta6);

if (resposta6 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 7
console.log(&quot;7) Qual é o maior animal terrestre?&quot;);
console.log(&quot;a) Elefante&quot;);
console.log(&quot;b) Leão&quot;);
let resposta7 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta7);

if (resposta7 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 8
console.log(&quot;8) Quantos continentes existem?&quot;);
console.log(&quot;a) 5&quot;);
console.log(&quot;b) 7&quot;);

let resposta8 = &quot;b&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta8);

if (resposta8 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 9
console.log(&quot;9) Qual é o idioma mais falado no mundo?&quot;);
console.log(&quot;a) Inglês&quot;);
console.log(&quot;b) Mandarim&quot;);
let resposta9 = &quot;a&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta9);

if (resposta9 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 10
console.log(&quot;10) Qual é o símbolo químico da água?&quot;);
console.log(&quot;a) H2O&quot;);
console.log(&quot;b) CO2&quot;);
let resposta10 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta10);

if (resposta10 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

console.log(&quot;Fim do quiz &quot;);

console.log(&quot;Seja bem-vindo ao Quiz de Entretenimento \n&quot;);

// Pergunta 1
console.log(&quot;1) Qual filme tem o personagem Homem-Aranha?&quot;);
console.log(&quot;a) Vingadores&quot;);
console.log(&quot;b) Homem-Aranha&quot;);
let resposta1 = &quot;b&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta1);

if (resposta1 == &quot;b&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: b\n&quot;);
}

// Pergunta 2
console.log(&quot;2) Quem canta a música &#39;Shape of You&#39;?&quot;);
console.log(&quot;a) Ed Sheeran&quot;);
console.log(&quot;b) Justin Bieber&quot;);
let resposta2 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta2);

if (resposta2 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 3
console.log(&quot;3) Qual é o nome do boneco em Toy Story?&quot;);
console.log(&quot;a) Woody&quot;);
console.log(&quot;b) Shrek&quot;);
let resposta3 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta3);

if (resposta3 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 4
console.log(&quot;4) Qual série tem dragões?&quot;);
console.log(&quot;a) Game of Thrones&quot;);
console.log(&quot;b) Friends&quot;);
let resposta4 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta4);

if (resposta4 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);

} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 5
console.log(&quot;5) Qual filme tem o personagem Elsa?&quot;);
console.log(&quot;a) Frozen&quot;);
console.log(&quot;b) Moana&quot;);
let resposta5 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta5);

if (resposta5 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 6
console.log(&quot;6) Qual é o nome do super-herói com martelo?&quot;);
console.log(&quot;a) Thor&quot;);
console.log(&quot;b) Hulk&quot;);
let resposta6 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta6);

if (resposta6 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 7
console.log(&quot;7) Qual é o nome do bruxo em Harry Potter?&quot;);
console.log(&quot;a) Harry&quot;);
console.log(&quot;b) Batman&quot;);
let resposta7 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta7);

if (resposta7 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 8
console.log(&quot;8) Qual banda cantava &#39;Beat It&#39;?&quot;);
console.log(&quot;a) Michael Jackson&quot;);
console.log(&quot;b) Queen&quot;);
let resposta8 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta8);

if (resposta8 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 9
console.log(&quot;9) Qual filme tem dinossauros?&quot;);

console.log(&quot;a) Jurassic Park&quot;);
console.log(&quot;b) Titanic&quot;);
let resposta9 = &quot;b&quot;; // ERRADA
console.log(&quot;Sua resposta: &quot; + resposta9);

if (resposta9 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

// Pergunta 10
console.log(&quot;10) Qual é o nome do vilão do Batman?&quot;);
console.log(&quot;a) Coringa&quot;);
console.log(&quot;b) Homem de Ferro&quot;);
let resposta10 = &quot;a&quot;; // CORRETA
console.log(&quot;Sua resposta: &quot; + resposta10);

if (resposta10 == &quot;a&quot;) {
console.log(&quot;Correto!\n&quot;);
} else {
console.log(&quot;Errado! Resposta correta: a\n&quot;);
}

console.log(&quot;Fim do quiz ��&quot;);