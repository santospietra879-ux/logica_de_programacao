console.log(&quot;O que estamos?&quot;)
console.log(&quot;A - 2026&quot;)
console.log(&quot;B - 2060&quot;)
console.log(&quot;C - 2058&quot;)
console.log(&quot;D - 2028&quot;)

let resposta = prompt(&quot;Digite a alternativa correta: &quot;).toLowerCase()

let acertos = 0
let erros = 0

switch(resposta) {
case &quot;a&quot;:
console.log(&quot;Alternativa correta!&quot;)
acertos++
break;

case &quot;b&quot;:
case &quot;c&quot;:
case &quot;d&quot;:
console.log(&quot;Alternativa incorreta!&quot;)
erros++
break;

default:
console.log(&quot;Resposta inválida&quot;)
}

console.log(&quot;Resultado final:&quot;)

console.log(&quot;Respostas corretas:&quot;, acertos)
console.log(&quot;Respostas incorretas:&quot;, erros)

let acertos = 0
let erros = 0

// PERGUNTA 1
console.log(&quot;1) Em que ano estamos?&quot;)
console.log(&quot;A- 2026\nB- 2060\nC- 2058\nD- 2028&quot;)
let r1 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r1){
case &quot;a&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;b&quot;: case &quot;c&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 2
console.log(&quot;\n2) Qual é a capital do Brasil?&quot;)
console.log(&quot;A- São Paulo\nB- Brasília\nC- Rio de Janeiro\nD- Salvador&quot;)
let r2 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r2){
case &quot;b&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;c&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 3
console.log(&quot;\n3) Quanto é 2 + 2?&quot;)
console.log(&quot;A- 3\nB- 4\nC- 5\nD- 6&quot;)
let r3 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r3){
case &quot;b&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;c&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)

}

// PERGUNTA 4
console.log(&quot;\n4) Qual linguagem estamos usando?&quot;)
console.log(&quot;A- Python\nB- Java\nC- JavaScript\nD- C++&quot;)
let r4 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r4){
case &quot;c&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;b&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 5
console.log(&quot;\n5) Qual é o maior planeta?&quot;)
console.log(&quot;A- Terra\nB- Marte\nC- Júpiter\nD- Vênus&quot;)
let r5 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r5){
case &quot;c&quot;:
console.log(&quot;Correta!&quot;)
acertos++

break;
case &quot;a&quot;: case &quot;b&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 6
console.log(&quot;\n6) Qual comando lista arquivos no Linux?&quot;)
console.log(&quot;A- cd\nB- ls\nC- rm\nD- pwd&quot;)
let r6 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r6){
case &quot;b&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;c&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 7
console.log(&quot;\n7) Qual comando cria pasta no Windows?&quot;)

console.log(&quot;A- del\nB- dir\nC- mkdir\nD- cd&quot;)
let r7 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r7){
case &quot;c&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;b&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 8
console.log(&quot;\n8) Qual é a cor do céu?&quot;)
console.log(&quot;A- Azul\nB- Verde\nC- Vermelho\nD- Amarelo&quot;)
let r8 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r8){
case &quot;a&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;b&quot;: case &quot;c&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++

break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 9
console.log(&quot;\n9) Quantos dias tem uma semana?&quot;)
console.log(&quot;A- 5\nB- 6\nC- 7\nD- 8&quot;)
let r9 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r9){
case &quot;c&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;b&quot;: case &quot;d&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// PERGUNTA 10
console.log(&quot;\n10) Qual é 10 / 2?&quot;)
console.log(&quot;A- 2\nB- 3\nC- 4\nD- 5&quot;)
let r10 = prompt(&quot;Resposta: &quot;).toLowerCase()

switch(r10){

case &quot;d&quot;:
console.log(&quot;Correta!&quot;)
acertos++
break;
case &quot;a&quot;: case &quot;b&quot;: case &quot;c&quot;:
console.log(&quot;Incorreta!&quot;)
erros++
break;
default:
console.log(&quot;Inválido&quot;)
}

// RESULTADO FINAL
console.log(&quot;\n=== RESULTADO FINAL ===&quot;)
console.log(&quot;Acertos:&quot;, acertos)
console.log(&quot;Erros:&quot;, erros)