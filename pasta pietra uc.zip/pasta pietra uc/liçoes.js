/*let valor1 = 10
let valor2 = 20
let soma = valor1 + valor2
console.log (soma)*/

/*let valor1 = 20
let valor2 = 10
let subtração = valor2 - valor1
console.log (subtração)*/

/*let valor1 = 5
let valor2 = 10
let mult = valor1 * valor2
console.log (mult)*/

/*let valor1 = 50
let valor2 = 5
let divisao = valor1 / valor2
console.log (divisao)*/

/*let valor1 = 10
let valor2 = 5
let maiorq = valor1 &gt; valor2
console.log (maiorq)*/

/*let valor1 = 10
let valor2 = 20
let menorq = valor1 &lt; valor2
console.log (menorq)*/

/*let valor1 = 25
let valor2 = 20
let maioig = valor1 &gt;= valor2
console.log (maioig)*/

/*let valor1 = 20
let valor2 = 25
let menoig = valor1 &lt;= valor2
console.log (menoig)*/

/*let valor1 = 10
valor1 ++
console.log (valor1)*/

/*let valor1 = 10
valor1 --
console.log (valor1)*/

/*let valor1 = 30
valor1 += 5
console.log (valor1)*/

/*let valor1 = 30
valor1 -= 5
console.log (valor1)*/

/*let valor1 = 30
let valor2 = 20

let dif = valor1 != valor2
console.log (dif)*/

/*let valor1 = 30
let valor2 = 20
let difes = valor1 !== valor2
console.log (difes)*/

/*let valor1 = 50
let valor2 = 50
let comp = valor1 == valor2
console.log (comp)*/

let valor1 = &quot;15&quot;
let valor2 = &quot;15&quot;
let compes = valor1 === valor2
console.log (compes)