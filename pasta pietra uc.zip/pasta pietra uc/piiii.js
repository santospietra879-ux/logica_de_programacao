function soma(a, b) {
return a + b
}

function subtracao(a, b) {
return a - b
}

function multiplicacao(a, b) {
return a * b
}

function divisao(a, b) {
return a / b
}

// Entrada de dados
let num1 = Number(prompt(&quot;Digite o primeiro número:&quot;))
let num2 = Number(prompt(&quot;Digite o segundo número:&quot;))
let operacao = prompt(&quot;Escolha: + - * /&quot;)

let resultado

if (operacao == &quot;+&quot;) {
resultado = soma(num1, num2)
} else if (operacao == &quot;-&quot;) {
resultado = subtracao(num1, num2)
} else if (operacao == &quot;*&quot;) {
resultado = multiplicacao(num1, num2)

if (idade &lt; 16) {
console.log(&quot;Não vota&quot;);
} else if (idade &gt;= 16 &amp;&amp; idade &lt; 18) {
console.log(&quot;Voto facultativo&quot;);
} else if (idade &gt;= 18 &amp;&amp; idade &lt; 70) {
console.log(&quot;Voto obrigatório&quot;);
} else {
console.log(&quot;Voto facultativo&quot;);
}

let numero = 5;

if (numero &gt; 0) {
console.log(&quot;Positivo&quot;);
} else if (numero &lt; 0) {
console.log(&quot;Negativo&quot;);
} else {
console.log(&quot;Zero&quot;);