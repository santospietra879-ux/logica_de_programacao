let nome = prompt(&quot;Digite seu nome:&quot;);
let idade = prompt(&quot;Digite sua idade:&quot;);

console.log(&quot;Olá, &quot; + nome + &quot;! Seja bem-vindo(a)&quot;);

// Verificar idade
if (idade &gt;= 18) {
console.log(&quot;Você é maior de idade.&quot;);
} else {
console.log(&quot;Você é menor de idade.&quot;);
}

// Pedir números
let numero1 = prompt(&quot;Digite o numero1:&quot;);
let numero2 = prompt(&quot;Digite o numero2:&quot;);

// Comparar números
if (numero1 == numero2) {
console.log(&quot;Os valores são iguais!&quot;);
} else {
console.log(&quot;Os valores são diferentes!&quot;);
}

let nome = prompt(&quot;Digite seu nome:&quot;);
let idade = prompt(&quot;Digite sua idade:&quot;);

console.log(&quot;Olá, &quot; + nome + &quot;!&quot;);

// Situação problema (sem redeclarar idade)

let temConvite = true;
let vip = false;

if (idade &gt;= 18 &amp;&amp; temConvite == true) {
console.log(&quot;Entrada permitida.&quot;);
// Verdadeiro: idade &gt;= 18 E tem convite
} else {
console.log(&quot;Entrada negada.&quot;);
// Falso: não atende todas as condições
}

if (idade &gt;= 18 &amp;&amp; temConvite == true || vip == true) {
console.log(&quot;Entrada liberada.&quot;);
// Verdadeiro: atende uma das condições
} else {
console.log(&quot;Entrada negada.&quot;);
// Falso: nenhuma condição foi atendida
}

let usuario = prompt(&quot;Digite o usuário:&quot;);
let senha = prompt(&quot;Digite a senha:&quot;);

if (usuario == &quot;Pietra&quot;) {
if (senha == &quot;1234&quot;) {
console.log(&quot;Usuário e senha corretos.&quot;);
// Verdadeiro: porque o usuário está correto e a senha também está
correta
} else {
console.log(&quot;Senha incorreta.&quot;);

// Falso: porque a senha digitada não é 1234
}
} else {
console.log(&quot;Usuário incorreto.&quot;);
// Falso: porque o usuário digitado não é Pietra
}
let numero = 5;

if (numero &gt; 0) {
console.log(&quot;Tabuada do &quot; + numero);

console.log(numero + &quot; x 1 = &quot; + (numero * 1));
console.log(numero + &quot; x 2 = &quot; + (numero * 2));
console.log(numero + &quot; x 3 = &quot; + (numero * 3));
console.log(numero + &quot; x 4 = &quot; + (numero * 4));
console.log(numero + &quot; x 5 = &quot; + (numero * 5));
console.log(numero + &quot; x 6 = &quot; + (numero * 6));
console.log(numero + &quot; x 7 = &quot; + (numero * 7));
console.log(numero + &quot; x 8 = &quot; + (numero * 8));
console.log(numero + &quot; x 9 = &quot; + (numero * 9));
console.log(numero + &quot; x 10 = &quot; + (numero * 10));

// Verdadeiro: porque o número é maior que 0, então mostra a tabuada
} else {
console.log(&quot;Número inválido.&quot;);
// Falso: porque o número não é maior que 0