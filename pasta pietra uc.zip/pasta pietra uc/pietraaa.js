let usuario = &quot;pietra&quot;
let senha = &quot;1234&quot;
let usuario1 = &quot;isabelly&quot;
let senha1 = &quot;4321&quot;
let usuario2 = &quot;caua&quot;
let senha2 = &quot;5654&quot;
let usuario3 = &quot;gabi&quot;
let senha3 = &quot;6767&quot;
let usuario4 = &quot;moises&quot;
let senha4 = &quot;7676&quot;
let usuario5 = &quot;lucas&quot;
let senha5 = &quot;0385&quot;
let usuario6 = &quot;felipe&quot;
let senha6 = &quot;5839&quot;
let usuario7 = &quot;james&quot;
let senha7 = &quot;2944&quot;
let usuario8 = &quot;vitor&quot;
let senha8 = &quot;3850&quot;
let usuario9 = &quot;Breno&quot;
let senha9 = &quot;0849&quot;

let usu1 = prompt(&quot;digite o seu usuario:&quot;)
let senh1 = prompt(&quot;digite a sua senha:&quot;)

function fazer_login(usu1, senh1) {
if (
(usu1 === usuario &amp;&amp; senh1 === senha) ||
(usu1 === usuario1 &amp;&amp; senh1 === senha1) ||
(usu1 === usuario2 &amp;&amp; senh1 === senha2) ||

(usu1 === usuario3 &amp;&amp; senh1 === senha3) ||
(usu1 === usuario4 &amp;&amp; senh1 === senha4) ||
(usu1 === usuario5 &amp;&amp; senh1 === senha5) ||
(usu1 === usuario6 &amp;&amp; senh1 === senha6) ||
(usu1 === usuario7 &amp;&amp; senh1 === senha7) ||
(usu1 === usuario8 &amp;&amp; senh1 === senha8) ||
(usu1 === usuario9 &amp;&amp; senh1 === senha9)
) {
console.log(&quot;Bem vindo ao sistema&quot;);
} else {
console.log(&quot;Usuário e senha incorretos&quot;);
}
}

fazer_login(usu1, senh1);